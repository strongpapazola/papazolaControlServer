-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 09 Mar 2020 pada 15.33
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `papazolaControl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `type` varchar(64) NOT NULL,
  `value` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `info`
--

INSERT INTO `info` (`id`, `type`, `value`) VALUES
(1, 'Name', 'exppar.bisaai.id'),
(2, 'IP', '127.0.0.1'),
(3, 'Status', 'Active'),
(4, 'Master', 'portal.bisaai.id'),
(5, 'PortSSH', '1022'),
(6, 'reboot', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `network_rule`
--

CREATE TABLE `network_rule` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `name_val` int(1) NOT NULL COMMENT '1 = off, 2 = on',
  `execute_val` int(1) NOT NULL COMMENT '1 = belum, 2 = sudah, 3 = warrning'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `network_rule`
--

INSERT INTO `network_rule` (`id`, `name`, `name_val`, `execute_val`) VALUES
(1, 'icmp', 2, 2),
(2, 'ssh', 2, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `val` int(1) NOT NULL COMMENT '1 = off, 2 = on, 3 = error',
  `execute` int(1) NOT NULL COMMENT '1 = belum, 2 = sudah',
  `information` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `services`
--

INSERT INTO `services` (`id`, `name`, `val`, `execute`, `information`) VALUES
(1, 'ssh', 2, 2, 'b\'     Active: active (running) since Fri 2020-03-06 19:11:21 WIB; 1 day 1h ago\\n\''),
(4, 'portsentry', 1, 2, 'b\'     Active: inactive (dead) since Mon 2020-03-09 21:32:43 WIB; 19ms ago\\n\'');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `network_rule`
--
ALTER TABLE `network_rule`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `network_rule`
--
ALTER TABLE `network_rule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
