<?php 
class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->__is_logged();
	}

	public function index()
	{
        $data = $this->db->get('session')->row_array();
		echo 'masih pembangunan, User : '.$data['username'];
		echo '<br><a href="'.base_url('index.php/auth/logout').'">logout</a>';
	}

	private function __is_logged()
	{
	    $data = $this->db->get('session')->row_array();
	    if (!$data) {
	          redirect(base_url()); 
	    } else {
	          if ($data['role_id'] != '1') {
	               redirect(base_url());                         
	          }                  
	    }
	}
}