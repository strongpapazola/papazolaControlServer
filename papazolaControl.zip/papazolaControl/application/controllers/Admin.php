<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model');
            $this->__is_logged();
	}

      private function __is_logged()
      {
            $data = $this->db->get('session')->row_array();
            if (!$data) {
                  redirect(base_url()); 
            } else {
                  if ($data['role_id'] != '2') {
                       redirect(base_url());                         
                  }                  
            }
      }

      public function index()
      {
            $data['session'] = $this->db->get('session')->row_array();
            $data['name'] = $this->Admin_model->getrow('info', 'type', 'Name');
            $data['ip'] = $this->Admin_model->getrow('info', 'type', 'IP');
            $data['status'] = $this->Admin_model->getrow('info', 'type', 'Status');
            $data['master'] = $this->Admin_model->getrow('info', 'type', 'Master');
            $data['portssh'] = $this->Admin_model->getrow('info', 'type', 'PortSSH');
            $data['services'] = $this->Admin_model->getall('services');
            $data['network_rules'] = $this->Admin_model->getall('network_rule');
            $this->load->view('admin/index',$data);                  
      }

      public function service($a, $b)
      {
            $this->Admin_model->updaterow('services', 'name', $a, 'val', $b, 'execute', 1);
            redirect(base_url('index.php/admin'));
      }
      public function network_rule($a, $b)
      {
            $this->Admin_model->updaterow('network_rule', 'name', $a, 'name_val', $b, 'execute_val', 1);
            redirect(base_url('index.php/admin'));
      }
      public function reboot()
      {
            $this->Admin_model->reboot();
            redirect(base_url('index.php/admin'));
      }
}

