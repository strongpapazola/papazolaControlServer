<?php
class Auth extends CI_Controller {

	private function __is_logged()
	{
        $data = $this->db->get('session')->row_array();
        if ($data) {
              if ($data['role_id'] == '2') {
                   redirect(base_url('index.php/admin'));                         
              } else {
                   redirect(base_url('index.php/user'));                         
              }
        }
	}

	public function index()
	{
		$this->__is_logged();
		$username = $this->input->post('username');
		if ($username) {
			$data = $this->db->get_where('user', ['username' => $username])->row_array();
			if ($username == $data['username']) {
				$password = $this->input->post('password');
				if (password_verify($password, $data['password'])) {
					$data = [
						'username' => $data['username'],
						'role_id' => $data['role_id']
					];
					$this->db->insert('session', $data);
					if ($data['role_id'] == 2 ) {
						redirect(base_url('index.php/admin'));
					} else {
						redirect(base_url('index.php/user'));
					}
				} else {
					$this->load->view('auth/index');
				}
			} else {
				$this->load->view('auth/index');
			}
		} else {
			$this->load->view('auth/index');
		}
	}

	public function logout()
	{
		$this->db->empty_table('session');
		redirect(base_url());
	}

	public function register($token = Null)
	{
		$this->__is_logged();
		if ($token == 'aiypwzqp040902') {
			$username = $this->input->post('username');
			if ($username) {
				$password = $this->input->post('password');			
				if ($password) {
					$username = htmlspecialchars($username);
					$password = htmlspecialchars($password);
					$data = [
						'username' => $username,
						'password' => password_hash($password, PASSWORD_DEFAULT),
						'role_id' => 1
					];
					$this->db->insert('user', $data);
					redirect(base_url());
				}
			} else {
				$this->load->view('auth/register');
			}
		} else {
			$this->load->view('index');
		}
	}
}