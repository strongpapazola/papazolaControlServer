<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Admin Console</title>

  <!-- Custom fonts for this template-->
  <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">


    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-light topbar mb-4 static-top shadow">

          
          

          <!-- Topbar Navbar -->
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
          <ul class="navbar-nav ml-auto">

          
            <!-- <div class="topbar-divider d-none d-sm-block"></div> -->

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $session['username']; ?></span>
                <img class="img-profile rounded-circle" src="https://avatars1.githubusercontent.com/u/48545591?s=460&v=4">
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?= base_url('index.php/auth/logout'); ?>">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <button class="btn btn-sm btn-primary" type="button" data-toggle="modal" data-target="#information"><i class="fas fa-download fa-sm text-white-50"></i> Information</button>
          </div>


            <!-- Modal -->
            <div class="modal fade" id="information" tabindex="-1" role="dialog" aria-labelledby="information" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="information">Information</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="card">
                      <ul class="list-group list-group-flush">
                        <li class="list-group-item">Name : <?= $name['value']; ?></li>
                        <li class="list-group-item">IP : <?= $ip['value']; ?></li>
                        <li class="list-group-item">Status : <?= $status['value']; ?></li>
                        <li class="list-group-item">Master : <?= $master['value']; ?></li>
                        <li class="list-group-item">Port SSH : <?= $portssh['value']; ?></li>
                      </ul>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>


          <!-- Content Row -->

          <div class="row">

            <!-- Area Chart -->
            <div class="col-xl-6 col-lg-7">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Service</h6>
                  <a href="<?= base_url('index.php/admin/reboot'); ?>" class="badge badge-sm badge-primary" onclick="return confirm('Are You Sure...?')">Reboot</a>
                </div>
                <!-- Card Body -->
                <div class="card-body table-responsive">
<table class="table">
  <thead>
    <tr>
      <th>#</th>
      <th>Name Service</th>
      <th>Service</th>
      <th>Status</th>
      <th>Action</th>
      <th>Info</th>
    </tr>
  </thead>
  <tbody>

<?php $i = 1; ?>
<?php foreach ($services as $service) : ?>

    <tr>
      <th scope="row"><?= $i; ?></th>
      <td><?= $service['name'] ?></td>
      <td>
        <?php if ($service['val'] == '2') { ?>
          <div class="badge badge-success">ON</div>
        <?php } elseif ($service['val'] == '1') { ?>
          <div class="badge badge-danger">OFF</div>
        <?php } else { ?>
          <div class="badge badge-warning">Warning</div>
        <?php } ?>
      </td>
      <td>
        <?php if ($service['execute'] == '2') { ?>
          <div class="badge badge-success">Executed</div>
        <?php } elseif ($service['execute'] == '1') { ?>
          <div class="badge badge-danger">Not Yet</div>
        <?php } else { ?>
          <div class="badge badge-warning">Warning</div>
        <?php } ?>
      </td>
      <td>
        <?php if ($service['val'] == '2') { ?>
          <a href="<?= base_url('index.php/admin/service'); ?>/<?= $service['name'] ?>/1" class="badge badge-danger">Matikan</a>
        <?php } elseif ($service['val'] == '1') { ?>
          <a href="<?= base_url('index.php/admin/service'); ?>/<?= $service['name'] ?>/2" class="badge badge-success">Nyalakan</a>
        <?php } else { ?>
          <a href="#" class="badge badge-warning">Error</a>
        <?php } ?>
      </td>
      <td>
        <button type="button" class="badge badge-primary" data-toggle="modal" data-target="#<?= $service['name']; ?>">info</button>
      </td>
    </tr>

<!-- Modal -->
<div class="modal fade" id="<?= $service['name']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<?= $service['information']; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- modal -->

            <?php $i++; ?>
            <?php endforeach; ?>


              </tbody>
            </table>

                </div>
              </div>
            </div>

            <!-- Area Chart -->
            <div class="col-xl-6 col-lg-7">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Network Rule</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body table-responsive">

                <table class="table">
                  <tr>
                    <th>#</th>
                    <th>Name Rule</th>
                    <th>Service</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                <?php $i = 1; ?>
                <?php foreach ($network_rules as $network_rule) : ?>
                  <tr>
                    <td><?= $i; ?></td>
                    <td><?= $network_rule['name']; ?></td>
                    <td>
                      <?php if ($network_rule['name_val'] == '2') { ?>
                        <div class="badge badge-success">ON</div>
                      <?php } elseif ($network_rule['name_val'] == '1') { ?>
                        <div class="badge badge-danger">OFF</div>
                      <?php } else { ?>
                        <div class="badge badge-warning">Warning</div>
                      <?php } ?>
                    </td>
                    <td>
                      <?php if ($network_rule['execute_val'] == '2') { ?>
                        <div class="badge badge-success">Executed</div>
                      <?php } elseif ($network_rule['execute_val'] == '1') { ?>
                        <div class="badge badge-danger">Not Yet</div>
                      <?php } else { ?>
                        <div class="badge badge-warning">Warning</div>
                      <?php } ?>
                    </td>
                    <td>

                      <?php if ($network_rule['name_val'] == '2') { ?>
                        <a href="<?= base_url('index.php/admin/network_rule'); ?>/<?= $network_rule['name'] ?>/1" class="badge badge-danger">Matikan</a>
                      <?php } elseif ($network_rule['name_val'] == '1') { ?>
                        <a href="<?= base_url('index.php/admin/network_rule'); ?>/<?= $network_rule['name'] ?>/2" class="badge badge-success">Nyalakan</a>
                      <?php } else { ?>
                        <a href="#" class="badge badge-warning">Error</a>
                      <?php } ?>

                    </td>
                  </tr>
                <?php $i++; ?>
                <?php endforeach; ?>
                </table>

                </div>
              </div>
            </div>


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; strongpapazola inc 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
</div>

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Bootstrap core JavaScript-->
  <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="<?= base_url('assets/'); ?>vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="<?= base_url('assets/'); ?>js/demo/chart-area-demo.js"></script>
  <script src="<?= base_url('assets/'); ?>js/demo/chart-pie-demo.js"></script>

</body>

</html>
