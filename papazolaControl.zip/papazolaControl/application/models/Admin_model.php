<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Controller {

	public function getall($table)
	{
		return $this->db->get($table)->result_array();
	}

	public function getrow($table, $column, $val)
	{
		return $this->db->get_where($table, [$column => $val])->row_array();
	}

	public function updaterow($table,$columnkey, $key, $columnval, $val, $columnval1, $val1)
	{
		$y = [
			$columnval => $val,
			$columnval1 => $val1
   		];
   		$this->db->where($columnkey, $key);
   		$this->db->update($table, $y);
	}
	public function reboot()
	{
		$y = [
			'value' => 2
   		];
   		$this->db->where('type', 'reboot');
   		$this->db->update('info', $y);
	}

}