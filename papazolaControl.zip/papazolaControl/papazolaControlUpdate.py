from os import system as sy

line = '===================================================================================='

print('System Update Launch...!!!')
sy('sleep 1')
sy('wget http://localhost/papazolaControlPackage.zip')
print(line)

print('Unzip Launch...!!!')
sy('sleep 1')
sy('unzip papazolaControlPackage.zip')
print(line)

print('Copy The sh & py File Trigger...!!!')
sy('sleep 1')
sy('cp papazolaControlPackage/papazolaControl.py papazolaControlApps/')
sy('cp papazolaControlPackage/papazolaControl.sh papazolaControlApps/')
print(line)

print('Moving Dir To /var/www/...!!!')
sy('sleep 1')
sy('rm -r /var/www/papazolaControl')
sy('mv papazolaControlPackage /var/www/papazolaControl')

print('Change Password Database & Link Config...!!!')
password = input("Password MySQL : ")
url = input("Input Link : ")
sy('sleep 1')
sy("sed -i \"s\'password' => ''\'password' => '"+password+"'\g\" /var/www/papazolaControl/application/config/database.php")
sy("sed -i \"s\$config['base_url'] = 'http://localhost/papazolaControl';\$config['base_url'] = 'https://"+url+"/papazolaControl';\g\" /var/www/papazolaControl/application/config/config.php")

exit()


