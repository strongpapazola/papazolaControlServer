watch --interval 60 python3 /home/infra/papazolaControl/papazolaControl.py &> /dev/null &
